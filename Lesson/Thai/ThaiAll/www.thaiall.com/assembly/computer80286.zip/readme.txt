��Ѻ��ا : 2549-11-17
����������� run ��੾�к�����ͧ��� 
����ͧ pentium �о� runtime error 200
����Ҽ���Һ�������������¹���� Turbo Pascal 7.0 
�֧�� patch ���� exe �ҡ http://www.brain.uni-freiburg.de
: computere.exe (Upgraded : English Language)
: computerg.exe (Upgraded : German Language)
: computer80286.exe (old version)
===========================================
Patch program for existing executable files
http://www.brain.uni-freiburg.de/~klaus/pascal/runerr200/download.html#TpPatch
===========================================
Name des Programmierers:        Martin Hund

Anschrift:                      Rheinstra�e 4 56370 Rettert
Telefon:                        06486/8679

Zur Erstellung des Programms wurde die Programmiersprache TURBO PASCAL in
der Version 7.0 verwendet.

Hardwarevoraussetzungen:    Rechner mit Intel 80286 CPU oder Nachfolgetypen
                            Math. Co-Prozessor nicht erforderlich
                            Anpassung an VGA oder IBM-8514 Grafikkarte 
                            erfolgt automatisch.


Zur Installation des Programms legen Sie die Diskette in Laufwerk A oder B.
Rufen Sie das Installationsprogramm auf , zB. mit A:INSTALL.

T�tigen Sie die gew�nschten Eingaben und lesen Sie die Informationen
in der oberen Bildh�lfte. Das installierte Programm wird mit dem Namen
                          COMPUTER
gestartet. Es ist m�glich, einen Dateinamen als Kommandozeilenparameter
einzugeben, wenn die Beispieldateien mitinstalliert wurden.


Das Programm COMPUTER simuliert einen einfachen �-Computer. Die Maschinen-
sprachebefehle k�nnen sowohl als Ganzes wie auch als Folge der zugeh�rigen
Mikroprogrammschritte abgearbeitet werden. Dabei wird der Signalflu� in
einem Blockschaltbild optisch anschaulich in seinem zeitlichen Ablauf darge-
stellt. Die Befehle k�nnen sowohl einzeln eingegeben, als auch in kleine Pro-
gramme gefa�t werden. Diese Programme werden als Datei gef�hrt und k�nnen so
auch gespeichert, geladen und ver�ndert werden. Als Vorgabe stehen Beispiel-
programme zur Verf�gung, deren Entwicklung innerhalb von gestaffelten �bungs-
aufgaben, die dem Handbuch zu entnehmen sind, vorgenommen wird.

