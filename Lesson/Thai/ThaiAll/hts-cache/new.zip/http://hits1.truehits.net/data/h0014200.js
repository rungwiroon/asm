var hash="vsPg9147Xf0OfbrX0BtdiA==";var turlnameindex='thaiabc.com';
var _hsv='lvs.truehits.in.th';
var _ht='goggen.php';
var _ctg='stat.php?login=thaiabc';
var _hc='h0014200';
var truehitsurl=document.URL;

var __th_free=1;
document.write("<script src='http://"+_hsv+"/func/th_donate_1.8.js'></script>");
document.write("<script src='http://"+_hsv+"/func/th_common_1.4.js'></script>");