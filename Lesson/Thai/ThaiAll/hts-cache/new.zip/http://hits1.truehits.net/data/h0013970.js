var hash="+dRHeuq4MZAHXvbvw2ae/A==";var turlnameindex='thainame.net';
var _hsv='lvs.truehits.in.th';
var _ht='goggen.php';
var _ctg='stat.php?login=thainame';
var _hc='h0013970';
var truehitsurl=document.URL;

var __th_free=1;
document.write("<script src='http://"+_hsv+"/func/th_donate_1.8.js'></script>");
document.write("<script src='http://"+_hsv+"/func/th_common_1.4.js'></script>");