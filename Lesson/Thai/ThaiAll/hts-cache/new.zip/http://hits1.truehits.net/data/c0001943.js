var hash="5rhM7sSw6EUGan3+/ZzHhQ==";var turlnameindex='yonok.ac.th';
var _hsv='lvs.truehits.in.th';
var _ht='goggen.php';
var _ctg='stat.php?login=yonok';
var _hc='c0001943';
var truehitsurl=document.URL;

var __th_free=1;
document.write("<script src='http://"+_hsv+"/func/th_donate_1.8.js'></script>");
document.write("<script src='http://"+_hsv+"/func/th_common_1.4.js'></script>");