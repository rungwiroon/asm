var hash="67+iRo3ZM6Az+z5sKnEOVQ==";var turlnameindex='122.154.225.2';
var _hsv='lvs.truehits.in.th';
var _ht='goggen.php';
var _ctg='stat.php?login=weblampang';
var _hc='i0015336';
var truehitsurl=document.URL;

var __th_free=1;
document.write("<script src='http://"+_hsv+"/func/th_donate_1.8.js'></script>");
document.write("<script src='http://"+_hsv+"/func/th_common_1.4.js'></script>");